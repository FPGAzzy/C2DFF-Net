from ultralytics import YOLO
import thop
import random
import numpy as np
import torch

import warnings

warnings.filterwarnings(
    "ignore",
    message=".*adaptive_max_pool2d_backward_cuda does not have a deterministic implementation.*"
)

if __name__ == '__main__':



    ############## 这是train的代码 ##############
    # model = YOLO(r"ultralytics/cfg/models/v8/yolov8.yaml")  # 初始化模型
    # model = YOLO(r"ultralytics/cfg/models/v8/yolov8-twoCSP-64.yaml")  # 初始化模型 纯Concact
    model = YOLO(r"ultralytics/cfg/models/v8/C2DFF.yaml")  # 初始化模型 纯Concact
    #
    model.train(data=r"ultralytics/cfg/datasets/mydata.yaml", batch=8,
                epochs=2,project='runs/detect/train', name='yolov8-twoCSP',
                amp=False,
                workers=4,
                optimizer='SGD',  # Optimizer AdamW SGD
                # cos_lr=True,  # Cosine LR Scheduler
                lr0=0.02,seed=0,imgsz=1024
                )  # 训练 mydata_FLIR.yaml540

    # model.train(data=r"ultralytics/cfg/datasets/mydata_FLIR.yaml", batch=8,
    #             epochs=2,project='runs/detect/train', name='yolov8-twoCSP',
    #             amp=False,
    #              workers=4,
    #             optimizer='SGD',  # Optimizer AdamW SGD
    #             # cos_lr=True,  # Cosine LR Scheduler
    #             lr0=0.02,seed=0
    #             )  # 训练 mydata_FLIR.yaml540

    ############## 这是val和predict的代码 ##############
    # VEDAI数据集
    # model = YOLO(r"E:\MUL\weights\C2DFF\vedai\C2DFF_VEDAI.pt")#我的模型
    # model.val(data=r"ultralytics/cfg/datasets/mydata.yaml", batch=1, save_json=True, save_txt=False)  # VEDAI数据集
    # model.predict(source=r"G:\KeYan\DATA\DroneVehicle\images\test\00013.jpg", save=True,visualize=True)  #   检测一个模态就会自动检测下一个模态 images可见光

    # 其他数据集
    # model = YOLO(r"E:\MUL\weights\C2DFF\FLIR\C2DFF_FLIR.pt")#我的模型
    # model.val(data=r"ultralytics/cfg/datasets/mydata_FLIR.yaml", batch=1, save_json=True, save_txt=False)  # VEDAI数据集

    # # model.predict(source=r"E:\MUL\ultralytics\Datasets\VEDAI_Mine\images\val", save=True)  #   检测一个模态就会自动检测下一个模态
    # model.predict(source=r"G:\KeYan\DATA\VEDAI_1024\images\test", save=True)  #   检测一个模态就会自动检测下一个模态
    # model.predict(source=r"E:/MUL/ultralytics/Datasets/FLIR_align_3class/images/test", save=True)  #   检测一个模态就会自动检测下一个模态

